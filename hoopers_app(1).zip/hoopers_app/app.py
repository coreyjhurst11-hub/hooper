"""
Hooper's Wallcovering — a small Flask app.

Serves the website and receives booking ("fitting request") submissions.
Every request is saved to a SQLite database. If SMTP environment variables
are set, each request is also emailed to the studio.

Studio: Valdosta, GA — serving South Georgia & the Georgia–South Carolina coast.

Run it locally (Python 3.14):
    pip install -r requirements.txt
    python app.py            # http://127.0.0.1:5000

In production (Railway, etc.) it is served by gunicorn — see the Dockerfile.
"""

import os
import re
import hmac
import sqlite3
import smtplib
from datetime import datetime, timezone
from email.message import EmailMessage

from flask import Flask, render_template, request, jsonify, Response

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# DB path is configurable so it can point at a mounted volume in production.
# On Railway, add a Volume (e.g. mounted at /data) and set DB_PATH=/data/submissions.db
# so submissions survive redeploys — the container filesystem is otherwise wiped.
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "submissions.db"))

STUDIO_EMAIL = os.environ.get("STUDIO_EMAIL", "beau@hooperwallcovering.com")
STUDIO_PHONE = "(912) 246-5927"
STUDIO_LOCATION = "Valdosta, GA — serving South Georgia & the GA–SC coast"

# Optional protection for the /requests admin page (recommended in production).
ADMIN_USER = os.environ.get("ADMIN_USER", "studio")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD")  # if unset, page is open (with a warning)

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


# --------------------------------------------------------------------------- #
# Database
# --------------------------------------------------------------------------- #
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    parent = os.path.dirname(DB_PATH)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS requests (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                created   TEXT NOT NULL,
                name      TEXT NOT NULL,
                email     TEXT NOT NULL,
                phone     TEXT NOT NULL,
                room      TEXT,
                pattern   TEXT,
                details   TEXT
            )
            """
        )


def save_request(data):
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO requests (created, name, email, phone, room, pattern, details)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                datetime.now(timezone.utc).isoformat(timespec="seconds"),
                data["name"], data["email"], data["phone"],
                data.get("room", ""), data.get("pattern", ""), data.get("details", ""),
            ),
        )
        return cur.lastrowid


# Initialise at import time so it works under gunicorn (Railway) too,
# not only when run as __main__.
init_db()


# --------------------------------------------------------------------------- #
# Optional email notification (only fires if SMTP_* env vars are present)
# --------------------------------------------------------------------------- #
def send_notification(data):
    host = os.environ.get("SMTP_HOST")
    if not host:
        return False  # email not configured — that's fine, it's still saved to the DB

    port = int(os.environ.get("SMTP_PORT", "587"))
    user = os.environ.get("SMTP_USER", "")
    password = os.environ.get("SMTP_PASS", "")
    sender = os.environ.get("SMTP_FROM", user or STUDIO_EMAIL)

    msg = EmailMessage()
    msg["Subject"] = f"Fitting request — {data['name']}"
    msg["From"] = sender
    msg["To"] = STUDIO_EMAIL
    msg["Reply-To"] = data["email"]
    msg.set_content(
        "A new fitting request from the website:\n\n"
        f"Name:      {data['name']}\n"
        f"Email:     {data['email']}\n"
        f"Telephone: {data['phone']}\n"
        f"Space:     {data.get('room') or '—'}\n"
        f"Pattern:   {data.get('pattern') or 'undecided'}\n\n"
        f"{data.get('details') or '(no extra notes)'}\n"
    )

    with smtplib.SMTP(host, port, timeout=15) as server:
        server.starttls()
        if user:
            server.login(user, password)
        server.send_message(msg)
    return True


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/book", methods=["POST"])
def book():
    data = request.get_json(silent=True) or request.form.to_dict()

    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    phone = (data.get("phone") or "").strip()
    room = (data.get("room") or "").strip()

    # server-side validation (never trust the browser alone)
    if not name:
        return jsonify(ok=False, error="Please share your name."), 400
    if not EMAIL_RE.match(email):
        return jsonify(ok=False, error="Please enter a valid email."), 400
    if not phone:
        return jsonify(ok=False, error="Please share a telephone number."), 400
    if not room:
        return jsonify(ok=False, error="Please choose a space."), 400

    clean = {
        "name": name, "email": email, "phone": phone, "room": room,
        "pattern": (data.get("pattern") or "").strip(),
        "details": (data.get("details") or "").strip(),
    }

    save_request(clean)
    try:
        send_notification(clean)
    except Exception as exc:  # email failure must never lose the saved request
        app.logger.warning("Email notification failed: %s", exc)

    first = name.split(" ")[0]
    return jsonify(
        ok=True,
        message=f"Thank you, {first} — your request is on its way. "
                f"Beau will write back within a day.",
    )


def _authorized():
    """True if the admin page may be shown. Enforced only when ADMIN_PASSWORD is set."""
    if not ADMIN_PASSWORD:
        return True
    auth = request.authorization
    return bool(
        auth
        and auth.username == ADMIN_USER
        and hmac.compare_digest(auth.password or "", ADMIN_PASSWORD)
    )


@app.route("/requests")
def requests_list():
    """A plain table of submissions for the studio. Protect it with ADMIN_PASSWORD in production."""
    if not _authorized():
        return Response(
            "Authentication required.",
            401,
            {"WWW-Authenticate": 'Basic realm="Hooper\'s studio"'},
        )

    with get_db() as conn:
        rows = conn.execute("SELECT * FROM requests ORDER BY id DESC").fetchall()

    body = "".join(
        "<tr>"
        f"<td>{r['id']}</td><td>{r['created']}</td><td>{r['name']}</td>"
        f"<td>{r['email']}</td><td>{r['phone']}</td><td>{r['room'] or ''}</td>"
        f"<td>{r['pattern'] or ''}</td><td>{(r['details'] or '')[:120]}</td>"
        "</tr>"
        for r in rows
    ) or "<tr><td colspan='8' style='padding:24px;color:#888'>No requests yet.</td></tr>"

    warning = (
        "" if ADMIN_PASSWORD else
        "<p style='background:#A31621;color:#F7F3EC;padding:10px 14px;margin:0 0 18px'>"
        "This page is unprotected. Set an <b>ADMIN_PASSWORD</b> environment variable "
        "to require a login.</p>"
    )

    return (
        "<!doctype html><meta charset='utf-8'>"
        "<title>Fitting requests · Hooper's</title>"
        "<style>body{font-family:Georgia,serif;background:#F7F3EC;color:#141210;margin:40px}"
        "h1{font-weight:500}table{border-collapse:collapse;width:100%;background:#fff}"
        "th,td{border:1px solid #e2dccf;padding:8px 10px;text-align:left;font-size:14px;vertical-align:top}"
        "th{background:#A31621;color:#F7F3EC}small{color:#A31621}</style>"
        f"{warning}"
        f"<h1>Fitting requests <small>({len(rows)})</small></h1>"
        "<table><tr><th>#</th><th>Received (UTC)</th><th>Name</th><th>Email</th>"
        "<th>Phone</th><th>Space</th><th>Pattern</th><th>Notes</th></tr>"
        f"{body}</table>"
    )


@app.route("/health")
def health():
    return jsonify(ok=True, service="hoopers-wallcovering")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
