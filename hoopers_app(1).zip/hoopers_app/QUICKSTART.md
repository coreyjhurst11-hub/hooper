# Hooper's Wallcovering — deploy to Railway (demo)

Railway uses the Dockerfile automatically (it pins Python 3.14 and runs the
server). Nothing to configure.

## Fastest: Railway CLI (deploys this folder directly — no GitHub needed)

```bash
npm i -g @railway/cli      # once
railway login
railway init               # name the project
railway up                 # builds & deploys this folder
railway domain             # creates your public URL
```

Open the URL it prints. Done.

## Or via GitHub

1. Push this folder to a GitHub repo.
2. Railway → New Project → Deploy from GitHub repo → pick it.
3. Service → Settings → Networking → Generate Domain.

That's it. The booking form saves submissions in the running container; view
them at `/your-url/requests`. (Fine for a demo — they reset if Railway
redeploys, which doesn't matter here.)

Contact in the site: beau@hooperwallcovering.com · (912) 246-5927
